define(function () {
    return (/^margin/);
});
