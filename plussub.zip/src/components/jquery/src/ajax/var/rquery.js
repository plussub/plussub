define(function () {
    return (/\?/);
});
