- Latest version, 
- implementation details, 
- and usage information
found at <http://code.google.com/p/json-xml-rpc/>