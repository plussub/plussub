// /*
// (function (i, s, o, g, r, a, m) {
//     i['GoogleAnalyticsObject'] = r;
//     i[r] = i[r] || function () {
//             (i[r].q = i[r].q || []).push(arguments);
//         }, i[r].l = 1 * new Date();
//     a = s.createElement(o);
//     a.async = 1;
//     a.src = g;
//     document.body.appendChild(a);
// })(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga'); // Note: https protocol here
//
// ga('create', 'UA-59648258-1', 'auto');
// ga('set', 'checkProtocolTask', function () {
// });
// ga('require', 'displayfeatures');*/
