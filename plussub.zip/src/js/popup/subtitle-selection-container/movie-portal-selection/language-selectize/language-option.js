/**
 * Created by sonste on 28.12.2016.
 */
Polymer({

    is: 'language-option',

    properties: {
        item: {
            type: Object,
            value: () => {},
        }
    },
});