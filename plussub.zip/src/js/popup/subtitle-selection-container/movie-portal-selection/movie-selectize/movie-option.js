/**
 * Created by sonste on 27.12.2016.
 */
Polymer({

    is: 'movie-option',

    properties: {
        item: {
            type: Object,
            value: () => {},
        }
    },
});