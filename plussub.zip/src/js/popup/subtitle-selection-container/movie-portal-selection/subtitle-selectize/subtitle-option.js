/**
 * Created by sonste on 28.12.2016.
 */
Polymer({

    is: 'subtitle-option',

    properties: {
        item: {
            type: Object,
            value: () => {},
        }
    },
});