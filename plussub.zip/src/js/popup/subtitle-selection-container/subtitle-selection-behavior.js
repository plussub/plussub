SubtitleSelectionBehavior = (function () {

    return {
        ready:function(){
            this.classList.add("subtitle-selection-element");
        }
    }
})();