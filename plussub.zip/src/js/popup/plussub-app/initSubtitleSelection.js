/**
 * Created by sbreitenstein on 19/01/17.
 */
(function() {
    document.querySelector("template#scope").selected = 0;
})();