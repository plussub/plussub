/**
 * Created by sonste on 23.04.2016.
 */
var credential = {
    opensubtitle:{
        username:'',
        password:''
    }
};